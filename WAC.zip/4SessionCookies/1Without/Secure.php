
<html>
    <head>
        <title>Secure Page</title>
    </head>
    <body>
        <h1 style="color:red">Secure Page</h1>
    </body>
</html>